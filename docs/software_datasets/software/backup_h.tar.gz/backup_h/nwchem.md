# nwchem

### Description

High-performance computational chemistry software

### Versions

* Negishi: 7.0.2
* Anvil: 7.0.2

### Module

You can load the modules by:

```
module load nwchem
```