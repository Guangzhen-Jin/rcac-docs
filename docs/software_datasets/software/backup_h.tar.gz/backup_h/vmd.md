# vmd

### Description

VMD is a molecular visualization program for displaying, animating, and analyzing large biomolecular systems using 3-D graphics and built-in scripting.

### Versions

* Gilbreth: 1.9.3
* Anvil: 1.9.3

### Module

You can load the modules by:

```
module load vmd
```
