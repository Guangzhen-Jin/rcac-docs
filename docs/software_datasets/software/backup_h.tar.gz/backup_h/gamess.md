# gamess

### Description

The General Atomic and Molecular Electronic Structure System (GAMESS) is a general ab initio quantum chemistry package.

### Versions

* Scholar: 17.09-r2-libcchem
* Gilbreth: 17.09-r2-libcchem

### Module

You can load the modules by:

```
module load gamess
```
